#ifndef SHELL_TROLL_H
#define SHELL_TROLL_H


class ShellTroll
{
public:
    void LOL();
};

#endif // SHELL_TROLL_H
