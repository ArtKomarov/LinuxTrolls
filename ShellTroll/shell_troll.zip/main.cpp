#include <iostream>
#include "shell_troll.h"

int main() {
    ShellTroll t;
    t.LOL();
    return 0;
}
